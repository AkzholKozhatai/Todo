package com.example.buysell.controllers;

import com.example.buysell.models.Product;
import com.example.buysell.models.User;
import com.example.buysell.services.ProductService;
import com.example.buysell.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.security.Principal;

@Controller
@RequiredArgsConstructor
public class ProductController {
    private final ProductService productService;

    @GetMapping("/")
    public String products(@RequestParam(name = "searchWord", required = false) String title, Principal principal, Model model) {
        model.addAttribute("products", productService.listProducts(title));
        model.addAttribute("user", productService.getUserByPrincipal(principal));
        model.addAttribute("searchWord", title);
        return "products";
    }

    @Autowired
    private UserService userService;

    @GetMapping("/product/{productId}")
    public String getProductInfo(@PathVariable("productId") Long productId, Model model, Principal principal) {
        User user = userService.getUserByProductId(productId);
        model.addAttribute("user", user);
        model.addAttribute("userByPrincipal", userService.getUserByPrincipal(principal));
        model.addAttribute("products", user.getProducts());
        return "product-info";
    }


    @PostMapping("/product/create")
    public String createProduct(@RequestParam("file1") MultipartFile file1, Product product, Principal principal) throws IOException {
        productService.saveProduct(principal, product, file1);
        return "redirect:/my/products";
    }

    @PostMapping("/product/delete/{id}")
    public String deleteProduct(@PathVariable Long id, Principal principal, RedirectAttributes redirectAttributes) {
        User user = productService.getUserByPrincipal(principal);
        if (user == null) {
            // Пользователь не найден, перенаправляем на страницу входа
            return "redirect:/login";
        }

        productService.deleteProduct(user, id);

        // Добавляем сообщение об успешном удалении продукта
        redirectAttributes.addFlashAttribute("successMessage", "Продукт успешно удален");

        return "redirect:/my/products";
    }


    @GetMapping("/my/products")
    public String userProducts(Principal principal, Model model) {
        User user = productService.getUserByPrincipal(principal);
        model.addAttribute("user", user);
        model.addAttribute("products", user.getProducts());
        return "my-products";
    }
}
