package com.example.buysell.controllers;

import com.example.buysell.models.User;
import com.example.buysell.models.enums.Role;
import com.example.buysell.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.security.Principal;
import java.util.Map;

@Controller
@RequiredArgsConstructor
@PreAuthorize("hasAuthority('ROLE_ADMIN')")
public class AdminController {
    private final UserService userService;

    @GetMapping("/admin")
    public String admin(Model model, Principal principal) {
        model.addAttribute("users", userService.list());
        model.addAttribute("user", userService.getUserByPrincipal(principal));
        return "admin";
    }

    @PostMapping("/admin/user/ban/{id}")
    public String userBan(@PathVariable("id") Long id) {
        userService.banUser(id);
        return "redirect:/admin";
    }

    @GetMapping("/admin/user/edit/{userId}")
    public String userEdit(@PathVariable("userId") Long userId, Model model, Principal principal) {
        User user = userService.getUserById(userId);
        model.addAttribute("user", user);
        model.addAttribute("allRoles", Role.values());
        model.addAttribute("currentUser", userService.getUserByPrincipal(principal));
        return "user-edit";
    }

    @PostMapping("/admin/user/edit/{userId}")
    public String userEdit(@PathVariable("userId") Long userId, @RequestParam Map<String, String> form) {
        User user = userService.getUserById(userId);
        if (user != null) {
            userService.changeUserRoles(user, form);
        } else {
            return "redirect:/admin";
        }
        return "redirect:/admin";
    }


}
